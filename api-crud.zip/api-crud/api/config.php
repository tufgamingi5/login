<?php
define('DB_NAME', 'unbin');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

    $kon = mysqli_connect("localhost", "root", "", "unbin") or die(mysqli_error());